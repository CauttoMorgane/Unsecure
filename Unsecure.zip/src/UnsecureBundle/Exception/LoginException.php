<?php

namespace UnsecureBundle\Exception;

class LoginException extends Exception
{
}
