<?php

namespace UnsecureBundle\Exception;

use Exception as PHPException;

class Exception extends PHPException
{
}
