<?php

namespace UnsecureBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class UnsecureBundle extends Bundle
{
}
